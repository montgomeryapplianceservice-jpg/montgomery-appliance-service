import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Montgomery Appliance Service',
  description: 'Book appliance repair in minutes — fast, reliable, local',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
