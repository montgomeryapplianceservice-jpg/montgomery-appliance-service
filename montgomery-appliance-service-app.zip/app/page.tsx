'use client'
import { useMemo, useState } from 'react'
import { CONFIG } from '../lib/config'

const DIC = {
  en: {
    title: 'Montgomery Appliance Service',
    subtitle: 'Book repair in minutes — fast, reliable, local',
    services: 'Repair • Installation • Diagnostics',
    book: 'Book a Service',
    track: 'Track Status',
    name: 'Full name',
    phone: 'Phone',
    email: 'Email',
    address: 'Service address',
    cityZip: 'City / ZIP',
    appliance: 'Appliance type',
    choose: 'Choose...',
    issue: 'Describe the issue',
    preferredDate: 'Preferred date',
    preferredTime: 'Preferred time',
    photos: 'Photos (optional)',
    submit: 'Submit Request',
    reset: 'Reset',
    successTitle: 'Request submitted!',
    successBody: (id:string) => `Your request #${id} has been received. We\'ll contact you shortly to confirm the appointment.`,
    lang: 'Русский',
    policy: 'By submitting you agree to our Terms and Privacy.',
    asap: 'ASAP', morning: 'Morning', afternoon: 'Afternoon', evening: 'Evening',
    payNow: (fee:number)=>`Pay diagnostic fee $${fee} now`,
    paid: 'Diagnostic fee paid',
    orPayLater: 'or pay on-site',
    idHint: 'Save your request number to track status',
    enterId: 'Enter request ID', find: 'Find', notFound: 'Request not found. Check the ID.',
    timeline: { submitted:'Submitted', confirmed:'Confirmed', scheduled:'Scheduled', completed:'Completed' }
  },
  ru: {
    title: 'Montgomery Appliance Service',
    subtitle: 'Закажите ремонт за минуты — быстро, надёжно, рядом',
    services: 'Repair • Installation • Diagnostics',
    book: 'Оформить заявку',
    track: 'Проверить статус',
    name: 'ФИО',
    phone: 'Телефон',
    email: 'Email',
    address: 'Адрес ремонта',
    cityZip: 'Город / ZIP',
    appliance: 'Тип техники',
    choose: 'Выберите...',
    issue: 'Опишите проблему',
    preferredDate: 'Желаемая дата',
    preferredTime: 'Желаемое время',
    photos: 'Фото (необязательно)',
    submit: 'Отправить заявку',
    reset: 'Сбросить',
    successTitle: 'Заявка отправлена!',
    successBody: (id:string) => `Ваша заявка №${id} получена. Мы свяжемся с вами для подтверждения времени.`,
    lang: 'English',
    policy: 'Отправляя заявку, вы принимаете Условия и Политику конфиденциальности.',
    asap: 'Как можно скорее', morning:'Утром', afternoon:'Днём', evening:'Вечером',
    payNow: (fee:number)=>`Оплатить диагностику $${fee} сейчас`,
    paid: 'Диагностика оплачена',
    orPayLater: 'или оплатить на месте',
    idHint: 'Сохраните номер заявки, чтобы отслеживать статус',
    enterId: 'Введите номер заявки', find:'Найти', notFound:'Заявка не найдена. Проверьте номер.',
    timeline: { submitted:'Отправлено', confirmed:'Подтверждено', scheduled:'Запланировано', completed:'Выполнено' }
  }
} as const

type LangKey = keyof typeof DIC
type StatusKey = 'submitted'|'confirmed'|'scheduled'|'completed'

const APPLIANCES = ['Refrigerator','Washer','Dryer','Dishwasher','Oven / Range','Cooktop','Microwave','Garbage Disposal','Other']

function generateId(){ return Math.random().toString(36).slice(2,8).toUpperCase() }
function saveRequests(list:any[]){ localStorage.setItem('mas_requests', JSON.stringify(list)) }
function loadRequests(){ try { return JSON.parse(localStorage.getItem('mas_requests')||'[]') } catch { return [] } }

export default function Page(){
  const [lang, setLang] = useState<LangKey>(typeof navigator!=='undefined' && navigator.language?.startsWith('ru') ? 'ru':'en')
  const t = useMemo(()=>DIC[lang],[lang])
  const [tab, setTab] = useState<'book'|'track'>('book')
  const [submittedId, setSubmittedId] = useState<string|null>(null)
  const [paid, setPaid] = useState(false)
  const [photoNames, setPhotoNames] = useState<string[]>([])
  const [form, setForm] = useState({name:'',phone:'',email:'',address:'',cityZip:'',appliance:'',issue:'',date:'',time:''})
  const [lookupId, setLookupId] = useState('')
  const [found, setFound] = useState<any|null>(null)

  function handleChange<K extends keyof typeof form>(k:K, v:(typeof form)[K]){ setForm(prev=>({...prev,[k]:v})) }
  function handleFiles(fs: FileList | null){ if(!fs) return; setPhotoNames(Array.from(fs).slice(0,5).map(f=>f.name)) }

  function openCheckout(){
    if (CONFIG.STRIPE_CHECKOUT_URL) {
      window.open(CONFIG.STRIPE_CHECKOUT_URL, '_blank')
    } else {
      setTimeout(()=>setPaid(true), 600)
      alert('Payment simulated for demo. Set NEXT_PUBLIC_STRIPE_CHECKOUT_URL in Vercel env to use real Checkout.')
    }
  }

  async function fireWebhooks(payload:any){
    const headers = {'Content-Type':'application/json'}
    try { if (CONFIG.SHEETS_WEBHOOK_URL) await fetch(CONFIG.SHEETS_WEBHOOK_URL,{method:'POST',headers,body:JSON.stringify(payload)}) } catch {}
    try { if (CONFIG.NOTION_WEBHOOK_URL) await fetch(CONFIG.NOTION_WEBHOOK_URL,{method:'POST',headers,body:JSON.stringify(payload)}) } catch {}
    try { if (CONFIG.EMAIL_WEBHOOK_URL) await fetch(CONFIG.EMAIL_WEBHOOK_URL,{method:'POST',headers,body:JSON.stringify({to:CONFIG.BUSINESS_EMAIL, subject:`New MAS request #${payload.id}`, text:JSON.stringify(payload,null,2)})}) } catch {}
  }

  async function onSubmit(e:React.FormEvent){
    e.preventDefault()
    const id = generateId()
    const payload = { id, ts:new Date().toISOString(), ...form, photos:photoNames, paid, status:'submitted' as StatusKey }
    const list = [payload, ...loadRequests()]
    saveRequests(list)
    fireWebhooks(payload)
    setSubmittedId(id)
  }
  function doLookup(){
    const item = loadRequests().find((x:any)=>x.id === lookupId.trim().toUpperCase())
    setFound(item||null)
  }
  function reset(){
    setForm({name:'',phone:'',email:'',address:'',cityZip:'',appliance:'',issue:'',date:'',time:''})
    setPhotoNames([]); setPaid(false); setSubmittedId(null)
  }

  return (
    <div className="min-h-screen">
      <header className="bg-teal-700 text-white">
        <div className="max-w-5xl mx-auto px-6 py-6 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold">{t.title}</h1>
            <p className="text-sm opacity-90">{t.services}</p>
          </div>
          <div className="flex gap-2">
            <a href={`tel:${CONFIG.BUSINESS_PHONE_E164}`} className="btn btn-secondary bg-white text-teal-700">Call {CONFIG.BUSINESS_PHONE_HUMAN}</a>
            <button onClick={()=>setLang(lang==='en'?'ru':'en')} className="btn btn-primary">{t.lang}</button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8 grid md:grid-cols-2 gap-6">
        <div className="card">
          <div className="flex gap-2 mb-4">
            <button className={`btn ${tab==='book'?'btn-primary':'btn-secondary'}`} onClick={()=>setTab('book')}>{t.book}</button>
            <button className={`btn ${tab==='track'?'btn-primary':'btn-secondary'}`} onClick={()=>setTab('track')}>{t.track}</button>
          </div>

          {tab==='book' ? (
            <>
              <p className="small mb-4">{t.subtitle}</p>

              {submittedId ? (
                <div className="card bg-teal-50 border border-teal-200">
                  <div className="font-semibold mb-1">{t.successTitle}</div>
                  <div className="text-sm mb-2">{t.successBody(submittedId)}</div>
                  <div className="small mb-3">{t.idHint}: <b>{submittedId}</b></div>
                  <div className="flex gap-2 flex-wrap">
                    <button className="btn btn-secondary" onClick={reset}>{t.reset}</button>
                    <a className="btn btn-primary" href={`tel:${CONFIG.BUSINESS_PHONE_E164}`}>Call now</a>
                  </div>
                </div>
              ) : (
                <form onSubmit={onSubmit} className="space-y-3">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <input className="input" placeholder={t.name} required value={form.name} onChange={e=>handleChange('name', e.target.value)} />
                    <input className="input" placeholder={`${t.phone} (e.g. ${CONFIG.BUSINESS_PHONE_HUMAN})`} required value={form.phone} onChange={e=>handleChange('phone', e.target.value)} />
                    <input className="input" type="email" placeholder={t.email} value={form.email} onChange={e=>handleChange('email', e.target.value)} />
                    <input className="input" placeholder={t.cityZip} value={form.cityZip} onChange={e=>handleChange('cityZip', e.target.value)} />
                  </div>
                  <input className="input" placeholder={t.address} value={form.address} onChange={e=>handleChange('address', e.target.value)} />
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <select className="input" value={form.appliance} onChange={e=>handleChange('appliance', e.target.value)}>
                      <option value="">{t.appliance} • {t.choose}</option>
                      {APPLIANCES.map(a=><option key={a} value={a}>{a}</option>)}
                    </select>
                    <div className="grid grid-cols-2 gap-3">
                      <input className="input" type="date" value={form.date} onChange={e=>handleChange('date', e.target.value)} aria-label={t.preferredDate} />
                      <select className="input" value={form.time} onChange={e=>handleChange('time', e.target.value)}>
                        <option value="">{t.preferredTime}</option>
                        <option value="asap">{t.asap}</option>
                        <option value="morning">{t.morning}</option>
                        <option value="afternoon">{t.afternoon}</option>
                        <option value="evening">{t.evening}</option>
                      </select>
                    </div>
                  </div>
                  <textarea className="input" placeholder={t.issue} value={form.issue} onChange={e=>handleChange('issue', e.target.value)} rows={5} />
                  <label className="label">{t.photos}</label>
                  <input className="input" type="file" multiple accept="image/*" onChange={e=>handleFiles(e.target.files)} />
                  {photoNames.length>0 && <div className="small">{photoNames.join(', ')}</div>}

                  <div className="card border border-gray-200">
                    <div className="text-sm font-medium mb-1">{paid ? t.paid : t.payNow(CONFIG.DIAGNOSTIC_FEE)}</div>
                    <div className="small mb-2">{t.orPayLater}</div>
                    {!paid && <button type="button" className="btn btn-primary" onClick={openCheckout}>{t.payNow(CONFIG.DIAGNOSTIC_FEE)}</button>}
                  </div>

                  <div className="small">{t.policy}</div>
                  <div className="flex gap-2">
                    <button type="submit" className="btn btn-primary">{t.submit}</button>
                    <button type="button" className="btn btn-secondary" onClick={reset}>{t.reset}</button>
                  </div>
                </form>
              )}
            </>
          ) : (
            <div className="space-y-3">
              <div className="flex gap-2">
                <input className="input" placeholder={t.enterId} value={lookupId} onChange={e=>setLookupId(e.target.value)} />
                <button className="btn btn-primary" onClick={doLookup}>{t.find}</button>
              </div>
              {found ? (
                <div className="space-y-2">
                  <div className="text-sm">ID: <b>{found.id}</b></div>
                  <div className="flex flex-wrap gap-2">
                    <span className={`pill ${'pill-active'}`}>{t.timeline.submitted}</span>
                    <span className={`pill ${found.status!=='submitted' ? 'pill-active':'pill-idle'}`}>{t.timeline.confirmed}</span>
                    <span className={`pill ${['scheduled','completed'].includes(found.status) ? 'pill-active':'pill-idle'}`}>{t.timeline.scheduled}</span>
                    <span className={`pill ${found.status==='completed' ? 'pill-active':'pill-idle'}`}>{t.timeline.completed}</span>
                  </div>
                  <div className="card">
                    <div className="text-sm font-medium">{found.appliance} — {found.issue}</div>
                    <div className="text-sm">{found.address} {found.cityZip && `• ${found.cityZip}`}</div>
                    <div className="text-sm">{found.date || '-'} {found.time && `• ${found.time}`}</div>
                    <div className="text-sm mt-2">Contact: {CONFIG.BUSINESS_PHONE_HUMAN} • {CONFIG.BUSINESS_EMAIL}</div>
                  </div>
                </div>
              ) : <div className="small">{t.notFound}</div>}
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="card">
            <h3 className="font-semibold mb-2">{t.services}</h3>
            <ul className="grid grid-cols-2 gap-2 text-sm">
              {APPLIANCES.slice(0,6).map(i=><li key={i} className="bg-teal-50 border border-teal-100 px-3 py-2 rounded-xl">{i}</li>)}
              <li className="bg-teal-50 border border-teal-100 px-3 py-2 rounded-xl">Ice maker</li>
              <li className="bg-teal-50 border border-teal-100 px-3 py-2 rounded-xl">Water leaks</li>
            </ul>
            <div className="text-sm mt-3">Serving Montgomery County, MD</div>
          </div>

          <div className="card text-sm">
            <div>Call: <a className="text-teal-700" href={`tel:${CONFIG.BUSINESS_PHONE_E164}`}>{CONFIG.BUSINESS_PHONE_HUMAN}</a></div>
            <div>Email: <a className="text-teal-700" href={`mailto:${CONFIG.BUSINESS_EMAIL}`}>{CONFIG.BUSINESS_EMAIL}</a></div>
            <div className="small mt-2">Mon–Sat 8:00–19:00 • Emergency slots available</div>
          </div>
        </div>
      </main>

      <footer className="py-10 text-center small">
        © {new Date().getFullYear()} Montgomery Appliance Service — {CONFIG.BUSINESS_PHONE_HUMAN} • {CONFIG.BUSINESS_EMAIL}
      </footer>
    </div>
  )
}
