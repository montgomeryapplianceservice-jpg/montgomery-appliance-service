# Montgomery Appliance Service — Client App (Next.js)

Features:
- Booking form (EN/RU), upload photos
- Diagnostic fee online (Stripe Checkout link — optional)
- Status tracking by request ID (localStorage prototype)
- Webhooks to Google Apps Script / Notion / Email

## Deploy on Vercel
1) Create a new repo on GitHub and upload this folder.
2) Import the repo in Vercel → Deploy.
3) (Optional) Set Environment Variables in Vercel:
   - NEXT_PUBLIC_STRIPE_CHECKOUT_URL
   - NEXT_PUBLIC_SHEETS_WEBHOOK_URL
   - NEXT_PUBLIC_NOTION_WEBHOOK_URL
   - NEXT_PUBLIC_EMAIL_WEBHOOK_URL
   - NEXT_PUBLIC_DIAGNOSTIC_FEE (default 50)

## Local dev
```bash
npm install
npm run dev
```
